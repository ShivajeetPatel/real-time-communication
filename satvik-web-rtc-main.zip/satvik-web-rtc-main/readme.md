# **Web RTC**

developed by sanat kumar mishra and satvik shukla


To run , type the following code in terminal

```bash
npm i
node app.js
```

To view , go to browser and type

=> https://localhost:5000
